export ARCH=arm
export CROSS_COMPILE=/opt/linaro-gcc-4.5-arm-linux-gnueabi-32bit/bin/arm-linux-gnueabi-
