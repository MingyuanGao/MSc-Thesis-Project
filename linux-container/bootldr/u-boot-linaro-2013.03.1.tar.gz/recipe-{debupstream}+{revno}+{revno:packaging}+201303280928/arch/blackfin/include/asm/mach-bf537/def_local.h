#include "gpio.h"
#include "portmux.h"
#include "ports.h"

#define BF537_FAMILY 1	/* Linux glue */
